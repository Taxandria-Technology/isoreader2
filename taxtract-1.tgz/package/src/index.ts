#!/usr/bin/env node

import * as h5wasm from "h5wasm/node";
import * as fs from "fs";
import { Command } from "commander";


let cliArg = new Command();
cliArg
    .option('-f, --file <path>', 'Path to the .tax file')
    .action((options) => {
        extract(options.file);
    });
cliArg.parse();

export async function extract(pathlike: string) {
    await h5wasm.ready;
    let file = new h5wasm.File(pathlike, 'r');
    let ds = file.get('amplifiers') as h5wasm.Dataset;

    let json: Record<string, unknown> = {
        archive_version: 1
    };
    let members = ds.metadata.compound_type?.members;
    if (!members) { return; }

    for ( let i = 0; i < members.length; i++ ) {
        let values = ds.value as ArrayLike<unknown>;
        json[members[i].name] = values[i];
    }

    let jsonString = JSON.stringify(json, null, 2);

    fs.writeFileSync(
        pathlike.replace('.tax', '.json'), jsonString
    );
    file.close();
}
